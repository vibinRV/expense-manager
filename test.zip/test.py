import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.pyplot as plt
csv_file2='groceries.csv'
data2 = pd.read_csv(csv_file2)
print(data2)

csv_file2='groceries.csv'
data2 = pd.read_csv(csv_file2)
print(data2)

csv_file3='food.csv'
data3 = pd.read_csv(csv_file3)
print(data3)

x=[360,4000, 234]
y=[32,53,43]

z=plt.pie(x,labels=y,autopct='%.2f%%')
z=plt.bar(x,y)
print(z)

k=[360,4000, 234]
v=[32,53,43]

u=plt.pie(k,labels=v,autopct='%.2f%%')
u=plt.bar(k,v)
print(u)

u=[360,4000, 234]
v=[32,53,43]

w=plt.pie(u,labels=v,autopct='%.2f%%')
f=plt.bar(x,y)
print(w)
print(f)
	
x = [1,2,3]
y = [2,4,1]
plt.plot(x, y)
plt.xlabel('price')
plt.ylabel('y - axis')
plt.title('food')
plt.show()
import pandas as pd
import matplotlib.pyplot as plt
csv_file2='groceries.csv'
data2 = pd.read_csv(csv_file2)
print(data2)
a=50000
b=30000
c=20000
csv_file2='groceries.csv'
data2 = pd.read_csv(csv_file2)
print(data2)

csv_file3='food (2).csv'
data3 = pd.read_csv(csv_file3)
print(data3)

##x=list(Genre)
##y=list(Votes)
from tkinter import *
root=Tk()
root.title('EXPENSE TRACKER')
root.geometry('1000*1000')
root.print('As per universal budgeting rule ',a,' can be your needs',b,' be your wants and ',c,' be your savings')


z=plt.pie(x,labels=y,autopct='%.2f%%')
z=plt.bar(x,y)
print(z)
m.mainloop()

csv_file2='groceries.csv'
data2 = pd.read_csv(csv_file2)
print(data2)

csv_file3='food.csv'
data3 = pd.read_csv(csv_file3)
print(data3)
root.mainloop()










